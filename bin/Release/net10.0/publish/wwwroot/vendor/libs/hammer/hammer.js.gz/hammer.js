import 'hammerjs/hammer.js';
